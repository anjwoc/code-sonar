"""Analysis helpers for ATLS."""
