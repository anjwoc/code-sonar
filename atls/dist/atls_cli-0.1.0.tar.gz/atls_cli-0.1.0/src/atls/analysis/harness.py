#!/usr/bin/env python3
"""
ATLS Harness Analysis

QA / GEMINI 중심의 harness-engineering 산출물을 만들기 위한 보조 모듈.
Jira live issue 결과가 있으면 병합하고, 없으면 adcenter 문서와 코드 흔적을
기반으로 worklist / analysis / prompt pack을 생성한다.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
from collections import defaultdict
from pathlib import Path


ATLS_DOC_RELATIVE_PATHS = [
    "docs/guides/USER_GUIDE.md",
    "docs/design/ATLS_GENERIC_CLI_DESIGN.md",
    "docs/design/ATLS_DAILY_TRIAGE_DESIGN.md",
    "docs/guides/MCP_vs_Scripts_Guide.md",
]

ADCENTER_DOC_RELATIVE_PATHS = [
    "README.md",
    "docs/rules.md",
    "docs/qa/2026-04-02-manual-test-guide.md",
    "docs/qa/2026-04-02-adcenter-registration-verification-checklist.md",
    "docs/testcase/registration-gap-analysis-ko.md",
    "src/services/registration/service.ts",
    "src/components/features/ad/registration/modules/GroupCreationModule.tsx",
    "src/components/features/ad/edit/AdGroupModify.tsx",
]

DEFAULT_FILE_MAP = {
    "validation": [
        "src/components/features/ad/registration/modules/GroupCreationModule.tsx",
        "src/components/features/ad/edit/AdGroupModify.tsx",
        "src/services/registration/validation.ts",
        "src/utils/bidBudgetConstants.ts",
    ],
    "payload mapping": [
        "src/components/features/ad/registration/modules/GroupCreationModule.tsx",
        "src/services/registration/service.ts",
        "src/actions/registration.ts",
    ],
    "state persistence": [
        "src/components/features/ad/registration/common/CampaignSelectionPanel.tsx",
        "src/components/features/ad/registration/modules/GroupCreationModule.tsx",
        "src/lib/store/features/adRegistration/adRegistrationSlice.ts",
    ],
    "modal UX": [
        "src/components/features/ad/registration/common/ProductSelectionLayer.tsx",
        "src/components/features/ad/registration/common/KeywordSelectionLayer.tsx",
        "src/components/features/ad/registration/modules/GroupCreationModule.tsx",
        "src/components/features/ad/edit/AdGroupModify.tsx",
    ],
    "pagination/list rendering": [
        "src/components/features/ad/registration/common/ProductSelectionLayer.tsx",
        "src/components/features/ad/registration/modules/GroupCreationModule.tsx",
    ],
    "naming/suffix policy": [
        "src/components/features/ad/registration/common/CampaignSelectionPanel.tsx",
        "src/components/features/ad/registration/modules/GroupCreationModule.tsx",
        "src/utils/nameInputUtils.ts",
    ],
    "backend dependency": [
        "src/services/registration/service.ts",
        "docs/testcase/registration-gap-analysis-ko.md",
        "docs/qa/2026-04-02-adcenter-registration-verification-checklist.md",
    ],
    "QA 문서 정합성": [
        "docs/qa/2026-04-02-manual-test-guide.md",
        "docs/qa/2026-04-02-adcenter-registration-verification-checklist.md",
        "docs/testcase/registration-gap-analysis-ko.md",
    ],
    "spec undecided": [
        "docs/qa/2026-04-02-adcenter-registration-verification-checklist.md",
        "docs/testcase/registration-gap-analysis-ko.md",
    ],
}


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return ""


def _extract_table_after_heading(text: str, heading: str) -> list[list[str]]:
    if heading not in text:
        return []
    lines = text[text.index(heading):].splitlines()[1:]
    raw_rows = []
    started = False
    for line in lines:
        if line.strip().startswith("|"):
            raw_rows.append(line.rstrip())
            started = True
            continue
        if started:
            break
    rows: list[list[str]] = []
    for line in raw_rows:
        if set(line.replace("|", "").strip()) <= {"-", " "}:
            continue
        parts = [part.strip() for part in line.strip().strip("|").split("|")]
        if parts:
            rows.append(parts)
    if rows:
        return rows[1:]
    return []


def _extract_section_bullets(text: str, heading: str) -> dict[str, list[str]]:
    if heading not in text:
        return {}
    lines = text[text.index(heading):].splitlines()[1:]
    current = ""
    sections: dict[str, list[str]] = defaultdict(list)
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("## "):
            break
        if stripped.startswith("### "):
            current = stripped[4:].strip()
            continue
        if stripped.startswith("- ") and current:
            sections[current].append(stripped[2:].strip())
    return dict(sections)


def _extract_open_gap_table(text: str) -> list[dict]:
    rows = _extract_table_after_heading(text, "### 스펙 확인 필요")
    items = []
    for row in rows:
        if len(row) < 3:
            continue
        items.append(
            {
                "item": row[0],
                "current_state": row[1],
                "needed_action": row[2],
            }
        )
    return items


def _normalize_issue_list(raw: str) -> list[str]:
    return [match for match in re.findall(r"(GEMINI-\d+|QA-\d+)", raw or "")]


def _parse_checklist_tasks(text: str) -> dict[str, dict]:
    rows = _extract_table_after_heading(text, "## 완료된 태스크 전체 목록")
    tasks: dict[str, dict] = {}
    for row in rows:
        if len(row) < 4:
            continue
        task_cell = row[0]
        status = row[1]
        commit = row[2]
        note = row[3]
        match = re.search(r"Task\s+([A-Z]-\d+)\s+(.*)", task_cell)
        if not match:
            continue
        task_id = match.group(1)
        title = match.group(2).strip()
        tasks[task_id] = {
            "task_id": task_id,
            "title": title,
            "completion_state": status,
            "commit": commit.strip("` "),
            "note": note,
            "source_doc": "docs/qa/2026-04-02-adcenter-registration-verification-checklist.md",
            "current_status": "regression_check" if "완료" in status else "pending",
        }
    return tasks


def _parse_manual_task_mapping(text: str) -> dict[str, dict]:
    rows = _extract_table_after_heading(text, "## 테스트 완료 후 Jira 상태 변경")
    mapping: dict[str, dict] = {}
    for row in rows:
        if len(row) < 3:
            continue
        issues = _normalize_issue_list(row[0])
        task_ids = [task.strip("` ") for task in re.findall(r"[A-Z]-\d+", row[1])]
        criteria = row[2]
        for task_id in task_ids:
            entry = mapping.setdefault(task_id, {"related_issues": [], "criteria": []})
            entry["related_issues"].extend(issue for issue in issues if issue not in entry["related_issues"])
            if criteria not in entry["criteria"]:
                entry["criteria"].append(criteria)
    return mapping


def _parse_gap_analysis(text: str) -> dict[str, list[str]]:
    return _extract_section_bullets(text, "## 중요도 높은 수정 태스크 리스트")


def _parse_gap_highlights(text: str) -> list[str]:
    if "## 핵심 해석" not in text:
        return []
    lines = text[text.index("## 핵심 해석"):].splitlines()[1:]
    bullets = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("## "):
            break
        if stripped.startswith("- "):
            bullets.append(stripped[2:].strip())
    return bullets


def _issue_lookup(jira_issues: list[dict]) -> dict[str, dict]:
    return {issue.get("key"): issue for issue in jira_issues if issue.get("key")}


def _derive_workflow_bucket(issue: dict | None, current_status: str) -> str:
    if issue and issue.get("workflow_bucket"):
        return issue["workflow_bucket"]
    if current_status == "regression_check":
        return "review"
    if current_status in {"pending", "needs_spec"}:
        return "todo"
    return "other"


def _derive_risk(issue: dict | None, related_issues: list[str], title: str) -> str:
    if issue and issue.get("risk_level"):
        return issue["risk_level"]
    lowered = (title or "").lower()
    if related_issues or any(keyword in lowered for keyword in ("payload", "validation", "period", "모달", "bid", "예산")):
        return "high"
    return "medium"


def _derive_action(issue: dict | None, title: str, current_status: str) -> str:
    if issue and issue.get("action_needed"):
        actions = issue["action_needed"]
        if isinstance(actions, list) and actions:
            return actions[0]
    lowered = (title or "").lower()
    if current_status == "regression_check":
        return "needs_qa_retest"
    if "spec" in lowered or "스펙" in lowered:
        return "needs_prd_confirmation"
    if "ux" in lowered or "문구" in lowered or "모달" in lowered:
        return "needs_ux_confirmation"
    return "needs_dev"


def _derive_category(text: str) -> str:
    lowered = (text or "").lower()
    if any(keyword in lowered for keyword in ("validation", "기간", "일예산", "입찰가", "메시지")):
        return "validation"
    if any(keyword in lowered for keyword in ("payload", "bidword", "itemblacklist", "전달", "매핑")):
        return "payload mapping"
    if any(keyword in lowered for keyword in ("복원", "localstorage", "state", "기본 선택", "fallback")):
        return "state persistence"
    if any(keyword in lowered for keyword in ("모달", "confirm", "팝업", "취소")):
        return "modal UX"
    if any(keyword in lowered for keyword in ("페이지네이션", "목록", "컬럼", "전체선택", "검색")):
        return "pagination/list rendering"
    if any(keyword in lowered for keyword in ("suffix", "이름", "campaign", "group")):
        return "naming/suffix policy"
    if any(keyword in lowered for keyword in ("backend", "api", "count", "0으로", "null", "응답")):
        return "backend dependency"
    if any(keyword in lowered for keyword in ("qa 표", "qa 문서", "체크리스트", "문서")):
        return "QA 문서 정합성"
    if any(keyword in lowered for keyword in ("스펙", "확정", "확인 필요")):
        return "spec undecided"
    return "payload mapping"


def _default_touchpoints(workspace_root: Path, category: str) -> list[str]:
    return [str(workspace_root / relative) for relative in DEFAULT_FILE_MAP.get(category, []) if (workspace_root / relative).exists()]


def _search_code_references(workspace_root: Path, identifiers: list[str]) -> dict[str, list[str]]:
    identifiers = [identifier for identifier in identifiers if identifier]
    if not identifiers:
        return {}
    if not shutil_which("rg"):
        return {}
    pattern = r"\b(?:%s)\b" % "|".join(re.escape(identifier) for identifier in identifiers)
    targets = []
    for relative in ("src", "docs"):
        path = workspace_root / relative
        if path.exists():
            targets.append(str(path))
    if not targets:
        return {}
    proc = subprocess.run(
        ["rg", "-n", "-S", pattern, *targets],
        capture_output=True,
        text=True,
        check=False,
    )
    refs: dict[str, list[str]] = defaultdict(list)
    if proc.returncode not in (0, 1):
        return {}
    for line in proc.stdout.splitlines():
        parts = line.split(":", 3)
        if len(parts) < 4:
            continue
        path, lineno, _, content = parts
        refs[path].append(f"{path}:{lineno} {content.strip()}")
    return dict(refs)


def shutil_which(binary: str) -> str | None:
    for path in os.environ.get("PATH", "").split(os.pathsep):
        candidate = Path(path) / binary
        if candidate.exists() and os.access(candidate, os.X_OK):
            return str(candidate)
    return None


def _touchpoint_summary(workspace_root: Path, identifiers: list[str], category: str) -> tuple[list[str], list[str]]:
    refs = _search_code_references(workspace_root, identifiers)
    touchpoints = list(refs.keys())[:6]
    evidence = [entry for entries in refs.values() for entry in entries[:2]][:8]
    if not touchpoints:
        touchpoints = _default_touchpoints(workspace_root, category)
    return touchpoints, evidence


def _task_approach(category: str) -> str:
    mapping = {
        "validation": "등록 화면과 수정 화면에서 UI validation을 선행하고, 서비스/서버 validation과 문구를 맞추는 이중 방어 구조다.",
        "payload mapping": "GroupCreationModule에서 사용자 입력을 payload로 조립하고 registration service/action 계층에서 최종 API shape를 확정하는 구조다.",
        "state persistence": "로컬 상태, Redux 저장 상태, localStorage fallback을 조합해 등록 플로우 상태를 유지하는 구조다.",
        "modal UX": "공통 레이어 컴포넌트와 화면별 상태 플래그로 열림/닫힘/confirm 분기를 제어하는 구조다.",
        "pagination/list rendering": "상품 선택 모달과 그룹 생성 화면에서 파생 목록을 계산하고 현재 페이지 상태에 따라 렌더링하는 구조다.",
        "naming/suffix policy": "추천 이름 생성과 저장 payload 이름을 화면 상태에서 계산하고 scene/type 별 규칙을 적용하는 구조다.",
        "backend dependency": "프론트는 service/action 계층에서 API 응답을 받아 매핑하지만 count/추천값의 source of truth는 백엔드에 의존한다.",
        "QA 문서 정합성": "코드 반영 결과와 QA 문서/체크리스트를 수동 검증 문서로 연결하는 운영 구조다.",
        "spec undecided": "현재 코드보다 상위 결정이 필요한 항목을 문서에서 보류하고, 구현은 최소 안전장치만 두는 구조다.",
    }
    return mapping.get(category, "등록 UI와 service 계층을 연결해 동작을 구현하는 구조다.")


def _task_problem(title: str, note: str, current_status: str) -> str:
    if current_status == "regression_check":
        return f"{title}는 코드 반영은 되었지만 QA 회귀 검증과 문서 정합성 확인이 계속 필요한 상태다."
    if "스펙" in note or "확정" in note:
        return f"{title}는 기대 동작이 완전히 확정되지 않아 구현보다 스펙 확인이 먼저 필요한 상태다."
    return f"{title}에서 화면 동작, payload, 문구, 상태 복원 중 하나가 기대값과 어긋날 가능성이 남아 있는 상태다."


def _task_root_cause(category: str) -> str:
    mapping = {
        "validation": "등록 화면과 수정 화면의 validation 규칙/문구가 분산되어 있거나 UI와 서버 검증 타이밍이 어긋나기 쉽다.",
        "payload mapping": "보이는 값과 실제 API payload source가 달라질 때 회귀가 발생하기 쉽다.",
        "state persistence": "scene/type 전환, localStorage fallback, Redux reset 시점이 엇갈리면 복원 불일치가 생긴다.",
        "modal UX": "닫기 경로가 여러 개인데 변경 감지와 confirm 조건이 한곳에 모이지 않으면 누락이 생긴다.",
        "pagination/list rendering": "필터링된 목록, 전체 선택, 페이지 보정이 다른 파생 상태를 쓰면 빈 페이지나 숨겨진 항목 선택 버그가 생긴다.",
        "naming/suffix policy": "추천명 규칙, sceneId, count API 응답, 표시 문자열 계산이 분산돼 정합성이 깨지기 쉽다.",
        "backend dependency": "프론트 fallback만으로는 API raw 응답 불일치나 0/null 정합성 문제를 해결할 수 없다.",
        "QA 문서 정합성": "코드는 수정됐지만 QA 체크 문서가 뒤늦게 반영되면 상태 판단이 엇갈린다.",
        "spec undecided": "기획/백엔드/QA 합의 전까지는 기준값이 흔들려 구현을 고정하기 어렵다.",
    }
    return mapping.get(category, "UI 상태와 API 연결 지점이 분산되어 회귀 여지가 있다.")


def _task_fix(category: str) -> str:
    mapping = {
        "validation": "상수/문구를 공통화하고 등록/수정 화면, service validation, 수동 QA 체크리스트를 하나의 기준으로 맞춘다.",
        "payload mapping": "payload 조립 위치를 좁히고 service 계층 테스트와 Network QA 시나리오를 함께 유지한다.",
        "state persistence": "scene/type source of truth를 하나로 줄이고 reset 시점과 localStorage fallback 우선순위를 명시한다.",
        "modal UX": "모든 닫기 경로를 공통 confirm 로직으로 수렴시키고 변경 감지 기준을 명시한다.",
        "pagination/list rendering": "displayed list 기준으로 전체선택/페이지 계산을 통일하고 페이지 감소 시 보정 로직을 둔다.",
        "naming/suffix policy": "추천명 생성 helper와 count 응답 파싱을 한곳으로 모으고 표시값/전달값을 같은 source로 계산한다.",
        "backend dependency": "프론트 로그와 raw API 응답을 함께 수집해 원인을 분리하고, 백엔드 확인 전에는 fallback 범위를 문서화한다.",
        "QA 문서 정합성": "체크리스트 status, 커밋, 연결 이슈를 주기적으로 갱신하고 회귀 테스트 케이스를 문서와 맞춘다.",
        "spec undecided": "기획/QA/API 팀 확인 항목을 먼저 닫고 그 결과를 기준으로 코드와 QA 문서를 동시에 갱신한다.",
    }
    return mapping.get(category, "source of truth를 줄이고 검증 시나리오를 코드와 문서 양쪽에 남긴다.")


def _task_validation_plan(task_id: str, related_issues: list[str], current_status: str) -> str:
    if current_status == "regression_check":
        return f"{task_id}는 수동 QA 가이드 기준으로 회귀 테스트하고, 연결 이슈 {', '.join(related_issues) or '없음'} 상태를 다시 맞춘다."
    if related_issues:
        return f"Network payload, 화면 메시지, 저장 결과를 함께 확인하고 {', '.join(related_issues)} 이슈 상태와 연결한다."
    return "문서 기대값, 실제 UI, payload 또는 저장 결과를 함께 대조해 기준을 확정한다."


def _build_qa_worklist(
    checklist_tasks: dict[str, dict],
    manual_mapping: dict[str, dict],
    jira_by_key: dict[str, dict],
) -> list[dict]:
    rows = []
    for task_id in sorted(checklist_tasks):
        task = dict(checklist_tasks[task_id])
        related_issues = manual_mapping.get(task_id, {}).get("related_issues", [])
        criteria = manual_mapping.get(task_id, {}).get("criteria", [])
        linked_issue = jira_by_key.get(related_issues[0]) if related_issues else None
        task.update(
            {
                "related_issue": ", ".join(related_issues),
                "workflow_bucket": _derive_workflow_bucket(linked_issue, task["current_status"]),
                "risk_level": _derive_risk(linked_issue, related_issues, task["title"]),
                "action_needed": _derive_action(linked_issue, task["title"], task["current_status"]),
                "one_line_summary": task["title"],
                "evidence": criteria + [task["note"]],
            }
        )
        rows.append(task)
    return rows


def _build_gemini_worklist(
    qa_worklist: list[dict],
    jira_issues: list[dict],
) -> list[dict]:
    issue_map: dict[str, dict] = {}
    for row in qa_worklist:
        for issue in _normalize_issue_list(row.get("related_issue", "")):
            entry = issue_map.setdefault(
                issue,
                {
                    "related_issue": issue,
                    "task_ids": [],
                    "source_docs": set(),
                    "current_status": row["current_status"],
                    "workflow_bucket": row["workflow_bucket"],
                    "risk_level": row["risk_level"],
                    "action_needed": row["action_needed"],
                    "one_line_summary": row["title"],
                    "evidence": [],
                },
            )
            if row["task_id"] not in entry["task_ids"]:
                entry["task_ids"].append(row["task_id"])
            entry["source_docs"].add(row["source_doc"])
            entry["evidence"].extend(row["evidence"][:2])

    for issue in jira_issues:
        if issue.get("track") != "gemini":
            continue
        key = issue.get("key")
        if not key:
            continue
        entry = issue_map.setdefault(
            key,
            {
                "related_issue": key,
                "task_ids": [],
                "source_docs": set(),
                "current_status": issue.get("workflow_bucket") or "pending",
                "workflow_bucket": issue.get("workflow_bucket") or "other",
                "risk_level": issue.get("risk_level") or "medium",
                "action_needed": ", ".join(issue.get("action_needed") or []),
                "one_line_summary": issue.get("summary") or key,
                "evidence": [],
            },
        )
        entry["workflow_bucket"] = issue.get("workflow_bucket") or entry["workflow_bucket"]
        entry["risk_level"] = issue.get("risk_level") or entry["risk_level"]
        entry["action_needed"] = ", ".join(issue.get("action_needed") or []) or entry["action_needed"]
        entry["one_line_summary"] = issue.get("summary") or entry["one_line_summary"]
        entry["evidence"].append(f"Jira status={issue.get('status')} priority={issue.get('priority')}")

    rows = []
    for key in sorted(issue_map):
        row = issue_map[key]
        rows.append(
            {
                "task_id": ", ".join(row["task_ids"]),
                "related_issue": key,
                "source_doc": ", ".join(sorted(row["source_docs"])) or "live_jira",
                "workflow_bucket": row["workflow_bucket"],
                "risk_level": row["risk_level"],
                "action_needed": row["action_needed"],
                "current_status": row["current_status"],
                "one_line_summary": row["one_line_summary"],
                "evidence": row["evidence"][:4],
            }
        )
    return rows


def _build_task_analysis(
    workspace_root: Path,
    qa_worklist: list[dict],
    gemini_worklist: list[dict],
    open_gap_items: list[dict],
) -> list[dict]:
    blockers_text = " / ".join(item["item"] for item in open_gap_items[:4])
    analysis_rows = []
    for track, worklist in (("qa", qa_worklist), ("gemini", gemini_worklist)):
        for row in worklist:
            title = row["one_line_summary"]
            category = _derive_category(" ".join([row.get("task_id", ""), title, " ".join(row.get("evidence", []))]))
            identifiers = [row.get("task_id", ""), row.get("related_issue", "")]
            touchpoints, code_evidence = _touchpoint_summary(workspace_root, identifiers, category)
            analysis_rows.append(
                {
                    "track": track,
                    "task_id": row.get("task_id", ""),
                    "related_issue": row.get("related_issue", ""),
                    "category": category,
                    "current_adcenter_approach": _task_approach(category),
                    "current_problem": _task_problem(title, " ".join(row.get("evidence", [])), row.get("current_status", "")),
                    "root_cause": _task_root_cause(category),
                    "recommended_fix": _task_fix(category),
                    "touchpoints": touchpoints,
                    "validation_plan": _task_validation_plan(
                        row.get("task_id", ""),
                        _normalize_issue_list(row.get("related_issue", "")),
                        row.get("current_status", ""),
                    ),
                    "blockers": blockers_text if category in {"backend dependency", "spec undecided"} else "",
                    "evidence": [row.get("source_doc", "")] + row.get("evidence", [])[:3] + code_evidence[:4],
                }
            )
    return analysis_rows


def _build_cross_track_insights(gap_highlights: list[str], qa_worklist: list[dict], gemini_worklist: list[dict]) -> list[str]:
    insights = [
        "반복 패턴은 validation, payload mapping, 상태 복원, 모달 confirm 누락, 문서-코드 정합성으로 수렴한다.",
        "QA 태스크는 대부분 구현 완료 후 회귀 검증 단계로 이동했지만, GEMINI 이슈 키 기준 추적이 여전히 필요하다.",
        "등록 화면과 수정 화면이 같은 정책을 공유해야 하는 항목에서 회귀가 자주 발생한다.",
        "보이는 값과 실제 API payload가 다른 케이스가 adcenter 등록 도메인의 대표 리스크다.",
    ]
    insights.extend(gap_highlights[:2])
    if len(qa_worklist) > len(gemini_worklist):
        insights.append("QA 문서 기준 task granularity가 GEMINI 이슈 granularity보다 더 세분화돼 있어 매핑 계층이 필요하다.")
    deduped = []
    for item in insights:
        if item and item not in deduped:
            deduped.append(item)
    return deduped[:5]


def _relative_existing_paths(base: Path, relatives: list[str]) -> list[str]:
    return [str(base / relative) for relative in relatives if (base / relative).exists()]


def _render_table(headers: list[str], rows: list[list[str]]) -> str:
    if not rows:
        return "_empty_\n"
    sep = "| " + " | ".join(headers) + " |\n"
    sep += "| " + " | ".join(["---"] * len(headers)) + " |\n"
    body = "".join("| " + " | ".join(row) + " |\n" for row in rows)
    return sep + body


def render_harness_summary_markdown(result: dict) -> str:
    qa_rows = [
        [
            row["task_id"],
            row["related_issue"] or "-",
            row["source_doc"],
            row["workflow_bucket"],
            row["risk_level"],
            row["action_needed"],
            row["current_status"],
            row["one_line_summary"],
            "<br>".join(row["evidence"][:2]) or "-",
        ]
        for row in result["qa_worklist"]
    ]
    gemini_rows = [
        [
            row["task_id"] or "-",
            row["related_issue"],
            row["source_doc"],
            row["workflow_bucket"],
            row["risk_level"],
            row["action_needed"],
            row["current_status"],
            row["one_line_summary"],
            "<br>".join(row["evidence"][:2]) or "-",
        ]
        for row in result["gemini_worklist"]
    ]
    lines = [
        "# QA / GEMINI Harness Summary",
        "",
        "## ATLS Summary",
    ]
    lines.extend(f"- {line}" for line in result["atls_summary_lines"])
    lines.extend(
        [
            "",
            "## QA Worklist",
            _render_table(
                ["task_id", "related_issue", "source_doc", "workflow_bucket", "risk_level", "action_needed", "current_status", "one_line_summary", "evidence"],
                qa_rows,
            ).rstrip(),
            "",
            "## GEMINI Worklist",
            _render_table(
                ["task_id", "related_issue", "source_doc", "workflow_bucket", "risk_level", "action_needed", "current_status", "one_line_summary", "evidence"],
                gemini_rows,
            ).rstrip(),
            "",
            "## Cross-track Insights",
        ]
    )
    lines.extend(f"- {line}" for line in result["cross_track_insights"])
    lines.extend(["", "## Open Gaps"])
    for item in result["open_gaps"]:
        lines.append(f"- {item['item']}: {item['current_state']} / {item['needed_action']}")
    return "\n".join(lines) + "\n"


def render_task_analysis_markdown(result: dict) -> str:
    rows = []
    for row in result["task_analysis"]:
        rows.append(
            [
                row["track"],
                row["task_id"] or "-",
                row["related_issue"] or "-",
                row["category"],
                row["current_adcenter_approach"],
                row["current_problem"],
                row["root_cause"],
                row["recommended_fix"],
                "<br>".join(row["touchpoints"][:3]) or "-",
                row["validation_plan"],
                row["blockers"] or "-",
                "<br>".join(row["evidence"][:3]) or "-",
            ]
        )
    lines = [
        "# QA / GEMINI Task Analysis",
        "",
        _render_table(
            ["track", "task_id", "related_issue", "category", "current_adcenter_approach", "current_problem", "root_cause", "recommended_fix", "touchpoints", "validation_plan", "blockers", "evidence"],
            rows,
        ).rstrip(),
    ]
    return "\n".join(lines) + "\n"


def _build_prompt_pack(result: dict) -> dict:
    workspace_root = result["workspace_root"]
    atls_docs = result["atls_doc_paths"]
    adcenter_docs = result["adcenter_doc_paths"]
    qa_task_ids = ", ".join(row["task_id"] for row in result["qa_worklist"][:12])
    gemini_issue_ids = ", ".join(row["related_issue"] for row in result["gemini_worklist"][:12])
    prompt_1 = f"""당신은 ATLS 기반 Jira triage analyst다.

목표:
1. ATLS 문서와 현재 수집된 QA/GEMINI 근거를 바탕으로 summary를 만든다.
2. QA와 GEMINI에 대해서만 작업 리스트를 정의한다.
3. deterministic 분류와 inference를 분리한다.

입력 컨텍스트:
- ATLS 문서: {', '.join(atls_docs)}
- adcenter 문서/코드: {', '.join(adcenter_docs)}
- 현재 QA 태스크 후보: {qa_task_ids}
- 현재 GEMINI 이슈 후보: {gemini_issue_ids}

실행 규칙:
1. collect -> analyze -> report 구조를 유지한다.
2. QA/GEMINI 외 트랙은 제외한다.
3. completed 태스크는 regression_check로 표기한다.
4. evidence 없는 추론은 금지한다.
5. output에는 ATLS Summary, QA Worklist, GEMINI Worklist, Cross-track Insights, Open Gaps를 포함한다.
6. 한국어로 작성한다.
"""

    prompt_2 = f"""당신은 adcenter implementation analyst다.

목표:
앞 단계에서 만든 QA/GEMINI worklist를 입력으로 받아 adcenter에서의 현재 접근 방식, 문제상황, 원인, 해결방법, 검증방법을 태스크별로 분석한다.

분석 대상 프로젝트:
- {workspace_root}

반드시 먼저 읽을 것:
- {', '.join(adcenter_docs)}

분석 규칙:
1. category는 validation / payload mapping / state persistence / modal UX / pagination/list rendering / naming/suffix policy / backend dependency / QA 문서 정합성 / spec undecided 중 하나로 분류한다.
2. page/component, actions, services, clients/api, store/local state 경계를 분리해서 설명한다.
3. 코드가 이미 반영된 태스크는 재개발이 아니라 regression_check 관점으로 분석한다.
4. 스펙 미확정 항목은 어느 팀 확인이 필요한지 먼저 적는다.
5. 출력에는 Executive Summary, Task-by-Task Analysis, Priority View, Final Recommendations를 포함한다.
6. 한국어로 작성한다.
"""

    combined = f"""{prompt_1}

---

그 결과를 입력으로 삼아 바로 아래 구현 분석도 이어서 수행하라.

{prompt_2}
"""
    return {
        "summary_and_worklist_prompt": prompt_1.strip(),
        "adcenter_task_analysis_prompt": prompt_2.strip(),
        "combined_prompt": combined.strip(),
    }


def render_prompt_markdown(prompt_pack: dict) -> str:
    lines = ["# QA / GEMINI Harness Prompts", ""]
    for key, value in prompt_pack.items():
        lines.append(f"## {key}")
        lines.append("```text")
        lines.append(value)
        lines.append("```")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def build_harness_report(
    atls_root: str | Path,
    workspace_root: str | Path,
    jira_issues: list[dict] | None = None,
    jira_context: dict | None = None,
) -> dict:
    atls_root = Path(atls_root).expanduser().resolve()
    workspace_root = Path(workspace_root).expanduser().resolve()
    jira_issues = jira_issues or []
    jira_context = jira_context or {}

    manual_guide_path = workspace_root / "docs/qa/2026-04-02-manual-test-guide.md"
    checklist_path = workspace_root / "docs/qa/2026-04-02-adcenter-registration-verification-checklist.md"
    gap_path = workspace_root / "docs/testcase/registration-gap-analysis-ko.md"

    manual_text = _read_text(manual_guide_path)
    checklist_text = _read_text(checklist_path)
    gap_text = _read_text(gap_path)

    checklist_tasks = _parse_checklist_tasks(checklist_text)
    manual_mapping = _parse_manual_task_mapping(manual_text)
    gap_sections = _parse_gap_analysis(gap_text)
    gap_highlights = _parse_gap_highlights(gap_text)
    open_gap_items = _extract_open_gap_table(checklist_text)
    jira_by_key = _issue_lookup(jira_issues)

    qa_worklist = _build_qa_worklist(checklist_tasks, manual_mapping, jira_by_key)
    gemini_worklist = _build_gemini_worklist(qa_worklist, jira_issues)
    task_analysis = _build_task_analysis(workspace_root, qa_worklist, gemini_worklist, open_gap_items)
    prompt_pack = _build_prompt_pack(
        {
            "workspace_root": str(workspace_root),
            "atls_doc_paths": _relative_existing_paths(atls_root, ATLS_DOC_RELATIVE_PATHS),
            "adcenter_doc_paths": _relative_existing_paths(workspace_root, ADCENTER_DOC_RELATIVE_PATHS),
            "qa_worklist": qa_worklist,
            "gemini_worklist": gemini_worklist,
        }
    )

    report = {
        "success": True,
        "workspace_root": str(workspace_root),
        "atls_root": str(atls_root),
        "jira_context": jira_context,
        "atls_doc_paths": _relative_existing_paths(atls_root, ATLS_DOC_RELATIVE_PATHS),
        "adcenter_doc_paths": _relative_existing_paths(workspace_root, ADCENTER_DOC_RELATIVE_PATHS),
        "atls_summary_lines": [
            "ATLS는 Jira/Confluence용 AI 친화 CLI이며 JSON 중심 출력과 artifact 저장 규칙을 가진다.",
            "핵심 흐름은 collect -> analyze -> report -> publish 이다.",
            "규칙 기반 필드는 track, workflow_bucket, risk_level, action_needed이고 AI 분석 필드는 요약/다음 액션 중심이다.",
            "현재 daily-review는 GEMINI/QA 우선 그룹화까지 제공하지만 adcenter 코드 접근 분석과 harness prompt pack은 별도 보강이 필요하다.",
            "이번 report는 QA/GEMINI만 남기고 other/ops/infra를 제외하도록 정제했다.",
            "완료된 checklist 태스크는 신규 개발이 아니라 regression_check 관점으로 재정의했다.",
            "adcenter 분석은 문서 근거, 코드 touchpoint, live Jira issue를 분리해서 합친다.",
            "산출물은 summary/worklist, task analysis, prompt pack 세 묶음으로 구성한다.",
        ],
        "qa_worklist": qa_worklist,
        "gemini_worklist": gemini_worklist,
        "task_analysis": task_analysis,
        "cross_track_insights": _build_cross_track_insights(gap_highlights, qa_worklist, gemini_worklist),
        "open_gaps": open_gap_items,
        "gap_sections": gap_sections,
        "gap_highlights": gap_highlights,
        "prompt_pack": prompt_pack,
    }
    return report
